CATEGORICAL = "categorical"
CONTINUOUS = "continuous"
ORDINAL = "ordinal"
