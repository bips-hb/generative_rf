mkdir last_result
for path in param runs save_model score_info
do
    mkdir last_result/${path}
done
